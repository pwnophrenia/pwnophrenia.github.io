#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"

int main()
{
  unsigned char buffer[32];
  FILE *ptr = NULL;
  int packet_header[2];
  printf(CYAN "=========================================\n");
  printf("  CloudEdge™ Sensor Telemetry Reader v1.3\n");
  printf("  Initializing secure data stream...\n");
  printf("=========================================\n\n" RESET);

  printf(CYAN "[INFO] Opening sensor log stream...\n" RESET);
  ptr = fopen("sensor.log", "rb");
  if (!ptr) {
    fprintf(stderr, RED "[ERROR] Failed to access sensor.log\n" RESET);
    return 1;
  }
  printf(GREEN "[OK]   Stream established. \n\n" RESET);
 
  if (fread(packet_header, sizeof(int), 2, ptr) == 2)
  {
    fread(buffer, sizeof(unsigned char), packet_header[1], ptr);
    printf(YELLOW "[DEBUG] Packet received: type=%d, length=%d\n" RESET,
           packet_header[0], packet_header[1]);
    printf("[DATA] %s\n", buffer);
    if (packet_header[0] == 4)
      printf(CYAN "[DEBUG] %p\n" RESET, buffer);
  }
  else
    fprintf(stderr, RED "[ERROR] Wrong log format\n\n", RESET);
  return 0;
}
